For more information, please visit my repo
https://github.com/Jame3673/coffee-table
